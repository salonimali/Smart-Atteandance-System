
from datetime import datetime,date,time
import face_recognition
import pickle
import cv2
import glob
from time import gmtime, strftime



days=["Monday","Tuesday","Wednesday","Thursday","Friday","Saturday","Sunday"]
import mysql.connector
mydb = mysql.connector.connect(
		host="localhost",
		user="root",
		passwd="",
		database="Attendence_System"
		)



def markAttendence( subject_name, table_name, list):
		now=strftime('%y-%m-%d  %H:%M', gmtime())
		print("Subject is in if",subject)
		print(list[0], list[1], list[2], list[3], list[4])
		print(list)
		sql = "INSERT INTO "+table_name+" (DateTime,S_15INFT10,S_15INFT18,S_15INFT33,S_15INFT47,S_15INFT49) VALUES (%s,%s,%s,%s,%s,%s)"
		val = (now,list[0],list[1],list[2],list[3],list[4])
		mycursor_1 = mydb.cursor()
		mycursor_1.execute(sql,val)
		mydb.commit()
		print(mycursor_1.rowcount,"record inserted")
		#time.sleep(60)
		return

def TakeClassPhotos():
	cam = cv2.VideoCapture(0)
	detector=cv2.CascadeClassifier('haarcascade_frontalface_default.xml')

	
	sampleNum=0
	while(True):
		ret, img = cam.read()
		#gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
		faces = detector.detectMultiScale(img, 1.3, 5)
		for (x,y,w,h) in faces:
			cv2.rectangle(img,(x,y),(x+w,y+h),(255,0,0),2)
			
			#incrementing sample number 
			sampleNum=sampleNum+1
			#saving the captured face in the dataset folder
			#cv2.imwrite("dataset/User."+Id +'.'+ str(sampleNum) + ".jpg", gray[y:y+h,x:x+w])
			cv2.imwrite("C:\\Users\\HP\\Desktop\\MegaProjct\\Group5_4-5-2019\\Class_Picture\\Student."+ str(sampleNum) + 
						".jpg", img[y:y+h,x:x+w])
			cv2.imshow('frame',img)
		#wait for 100 miliseconds 
		if cv2.waitKey(10) & 0xFF == ord('q'):
			break
		# break if the sample number is morethan 10
		elif sampleNum>20:
			break
	cam.release()
	cv2.destroyAllWindows()






while True:
		now = datetime.now()
		wd=datetime.today().weekday()
		Day=days[wd]
		current_time = now.strftime("%I:%M %p")
		print("Current Time =", current_time)

		t="'"+current_time+"'"
		


		if current_time=="12:13 PM" or current_time=="11:00 AM" or current_time=="11:30 AM":
			TakeClassPhotos()
			list=[0,0,0,0,0]
			sql="SELECT "+Day+" FROM mysite_beit_timetablr WHERE Time= ""'"+current_time+"'"
			mycursor = mydb.cursor()

			mycursor.execute(sql)
			
			data=mycursor.fetchall() 
			subject=str(data[0][0])
			print("subject is",subject)

			
			print(type(subject))

		 

			# load the known faces and embeddings
			print("[INFO] loading encodings...")
			data = pickle.loads(open("C:\\Users\\HP\\Desktop\\MegaProjct\\Group5_4-5-2019\\encodings.pickle", "rb").read())

			# load the input image and convert it from BGR to RGB
			
			for imagepath in glob.glob("C:\\Users\\HP\\Desktop\\MegaProjct\\Group5_4-5-2019\\Class_Picture\\*.jpg"):

				image=cv2.imread(str(imagepath))
				rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)

				# detect the (x, y)-coordinates of the bounding boxes corresponding
				# to each face in the input image, then compute the facial embeddings
				# for each face
				print("recognizing faces...")
				boxes = face_recognition.face_locations(rgb,
				 model="cnn")
				encodings = face_recognition.face_encodings(rgb, boxes)

				# initialize the list of names for each face detected
				names = []

				# loop over the facial embeddings
				for encoding in encodings:
				 # attempt to match each face in the input image to our known
				 # encodings
				 matches = face_recognition.compare_faces(data["encodings"],
					encoding)
				 name = "Unknown"

					 # check to see if we have found a match
				if True in matches:
					# find the indexes of all matched faces then initialize a
					# dictionary to count the total number of times each face
					# was matched
					matchedIdxs = [i for (i, b) in enumerate(matches) if b]
					counts = {}

					# loop over the matched indexes and maintain a count for
					# each recognized face face
					for i in matchedIdxs:
						name = data["names"][i]
						counts[name] = counts.get(name, 0) + 1

					# determine the recognized face with the largest number of
					# votes (note: in the event of an unlikely tie Python will
					# select first entry in the dictionary)
					name = max(counts, key=counts.get)
					
					if name=="18":
					 list[1]=1
					 print("18	",list[1])
					if name=="33":
					 list[2]=1
					 print("33	",list[2])
					if name=="47":
					 list[3]=1
					 print("47	",list[3])
					if name=="49":
					 list[4]=1
					 print("49	",list[4])
					if name=="10":
					 list[0]=1
					 print("10	",list[0])
						
					print(list)	
				 # update the list of names
					names.append(name)
					print(name)



					


			
			subject=subject.strip()       
			if(subject=="AST"):
					print("IN AST")
					markAttendence(subject,"mysite_ast_attendence", list)
			if(subject=="SN"):
					print("IN SN")
					markAttendence(subject,"mysite__sn_attendence", list)
			if(subject=="PHP"):
					print("IN PHP")
					markAttendence(subject,"mysite_php_attendence", list)    
			
			'''if(subject=="CC"):
					print("IN CC")
					markAttendence(subject,"mysite_beit_cc_attendence")
			if(subject=="WT"):
					print("IN WT")
					markAttendence(subject,"mysite_beit_wt_attendence")
			if(subject=="BIS"):
					print("IN BIS")
					markAttendence(subject,"mysite_beit_bis_attendence")
			if(subject=="ITBM"):
					print("IN ITBM")
					markAttendence(subject,"mysite_beit_itbm_attendence")''' 






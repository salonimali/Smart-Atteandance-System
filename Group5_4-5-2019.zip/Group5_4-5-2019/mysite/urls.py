"""mysite URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin

from django.urls import path
from mysite.polls import views
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [path('', views.index, name='index'),
			   path('login/',views.login, name='login'),
			   path('login/TrainStudentData/',views.TrainStudentData, name='TrainStudentData'),
               path('login/index/', views.index, name='index'),
			   path('Regi/',views.Regi,name='Regi'),
			   
               path('SRegi/',views.SRegi,name='SRegi'),
			   path('Upload_Photos_fun/Upload_Photos/',views.Upload_Photos,name='Upload_Photos'),
			   path('Upload_Photos_fun/',views.Upload_Photos_fun,name='Upload_Photos_fun'),
               path('login/login/',views.login, name='login'),
               path('login/logout/',views.logout,name='logout'),
			   path('login/getmyattendence/logout/',views.logout,name='logout'),
			   path('login/mark_attendence_manually/logout/',views.logout,name='logout'),
			   path('login/getsubjectattendence/logout/',views.logout,name='logout'),
              
               path('Regi/upload_faculty_data/',views.upload_faculty_data,name='upload_faculty_data'),
               path('SRegi/upload_student_data/',views.upload_student_data,name="upload_student_data"),
               path("login/getStudentHomepage/",views.getStudentHomepage,name="getStudentHomepage"),
               path("login/getmyattendence/",views.getmyattendence,name="getmyattendence"),
			   path("login/getmyattendence/",views.getmyattendence,name="getmyattendence"),
			   path("login/getsubjectattendence/",views.getsubjectattendence,name="getsubjectattendence"),
			   path("login/mark_attendence_manually/",views.mark_attendence_manually,name="mark_attendence_manually"),
               path("login/mark_attendence_manually/save_attendenace_manually/",views.save_attendenace_manually,name="save_attendenace_manually"),

               path('admin/', admin.site.urls),
]

from django.shortcuts import render, get_object_or_404,redirect
from django.http import HttpResponse
from .models import *
from django.shortcuts import render_to_response
from django.contrib.sessions.backends.db import SessionStore

from time import gmtime, strftime
name=""
roll_no=""

from django.http import HttpResponseRedirect

def index(request):
	return render(request, "index.html")

	
def Regi(request):
	return render(request, "Registration.html")

	
def SRegi(request):
	return render(request, "StudentRegistration.html")


def getStudentHomepage(request):
	return render(request, "homepagestudent.html")

def Upload_Photos_fun(request):
	return render(request, "Upload_Photos.html")
	


def TrainStudentData(request):
	
	
	# import the necessary packages
	from imutils import paths
	import face_recognition
	import argparse
	import pickle
	import cv2
	import os

	

	# grab the paths to the input images in our dataset
	print("[INFO] quantifying faces...")
	imagePaths = list(paths.list_images("C:\\Users\\HP\\Desktop\\MegaProjct\\Group5_4-5-2019\\dataset"))

	# initialize the list of known encodings and known names
	knownEncodings = []
	knownNames = []

	# loop over the image paths
	for (i, imagePath) in enumerate(imagePaths):
		# extract the person name from the image path
		print("[INFO] processing image {}/{}".format(i + 1,
			len(imagePaths)))
		name = imagePath.split(os.path.sep)[-2]

		# load the input image and convert it from RGB (OpenCV ordering)
		# to dlib ordering (RGB)
		image = cv2.imread(imagePath)
		rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)

		# detect the (x, y)-coordinates of the bounding boxes
		# corresponding to each face in the input image
		boxes = face_recognition.face_locations(rgb,
			model="cnn")

		# compute the facial embedding for the face
		encodings = face_recognition.face_encodings(rgb, boxes)

		# loop over the encodings
		for encoding in encodings:
			# add each encoding + name to our set of known names and
			# encodings
			knownEncodings.append(encoding)
			knownNames.append(name)

	# dump the facial encodings + names to disk
	print("[INFO] serializing encodings...")
	data = {"encodings": knownEncodings, "names": knownNames}
	f = open(args["encodings"], "wb")
	f.write(pickle.dumps(data))
	f.close()
	message="Trained successfully....."
	return redirect("admin.html",{'Message':message})
	
	
	




def login(request):
	userid=request.POST["User_id"]
	password=request.POST["Password"]
	print("user id is ",userid)
	print("password is ", password)
	
	
	flag=0
	
	str=userid[:4]
	if(str =="DKTE"):
		passw=FacultyDetails.objects.filter(Teacher_id=userid).values('Password')
		print("Password from db is",passw)
		ans = list(passw)
		if(len(ans)!=0):
			if(password==ans[0]['Password']):
				print("Valid User of faculty")
				request.session['userid']=userid
				return render(request,"homepagefaculty.html")
			else:
				flag=1
		else:
			flag=1

	
	if(userid=="admin" and password=="admin"):
		return render(request, "admin.html")
		

	if(userid !="DKTE" and userid !="admin"):
		print("In Student")
		passw = StudentDetails.objects.filter(Iso_RollNo="S_"+userid).values('Password')
		print("Password from db is", passw)
		ans = list(passw)
		print("ans is", ans)
		if(len(ans)!=0):
			if (password == ans[0]['Password']):
				print("Valid User of student")
				request.session['userid']=userid

				return render(request,'homepagestudent.html')
			else:
				flag=1
		else:
			flag=1

				
	if(flag==1):
		print("Invalid user")
		message="Invalid userID or Password"
		return render(request,'index.html',{'Message':message})
	

	


def logout(request):
	try:
		del request.session['userid']
		print("Session deleted successfully")
	except:
		pass
	return render(request, "index.html")


def upload_faculty_data(request):
	name=request.POST["Faculty_Name"]
	t_id=request.POST["Teacher_id"]
	sub=request.POST["Subject"]
	department=request.POST["Department"]
	password=request.POST["Password"]
	c_password=request.POST["C_Password"]
	print(name)
	print(t_id)
	print(sub)
	print(department)
	print(password)
	if(password==c_password):
		faculty_details=FacultyDetails(Name=name,Teacher_id=t_id,Subject=sub,Deapartment=department,Password=password)
		faculty_details.save()
		message="Registered Successfully"
		return render_to_response("index.html",{'Message':message})
	else:
		return render(request, "Registration.html")



def upload_student_data(request):
	name=request.POST["Student_Name"]
	roll_no=request.POST["Iso_RollNo"]
	e_id=request.POST["Email_id"]
	department=request.POST["Class"]
	password=request.POST["Password"]
	c_password=request.POST["C_Password"]
	print(name)
	print(roll_no)
	print(e_id)
	print(department)
	print(password)
	if(password==c_password):
		student_details=StudentDetails(Name=name,Iso_RollNo="S_"+roll_no,Email_id=e_id,Class=department,Password=password)
		student_details.save()
		message="Registered Successfully"
		return render_to_response("index.html",{'Message':message})
	else:
		message="Error during Registration "
		return render_to_response("StudentRegistration.html",{'Message':message})
		


def Upload_Photos(request):
	import cv2
	cam = cv2.VideoCapture(0)
	detector=cv2.CascadeClassifier('haarcascade_frontalface_default.xml')
	print("IN UP..")
	# Id=input('enter your id')
	Id=request.POST['Iso_RollNo']
	print(Id)
	sampleNum=0
	while(True):
		ret, img = cam.read()
		#gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
		faces = detector.detectMultiScale(img, 1.3, 5)
		for (x,y,w,h) in faces:
			cv2.rectangle(img,(x,y),(x+w,y+h),(255,0,0),2)
			
			#incrementing sample number 
			sampleNum=sampleNum+1
			#saving the captured face in the dataset folder
			#cv2.imwrite("dataset/User."+Id +'.'+ str(sampleNum) + ".jpg", gray[y:y+h,x:x+w])
			cv2.imwrite("C:\\Users\\HP\\Desktop\\MegaProjct\\Group5_4-5-2019\\dataset\\"+Id+"\\Student."+Id +'.'+ str(sampleNum) + 
						".jpg", img[y:y+h,x:x+w])
			cv2.imshow('frame',img)
		#wait for 100 miliseconds 
		if cv2.waitKey(10) & 0xFF == ord('q'):
			break
		# break if the sample number is morethan 10
		elif sampleNum>20:
			break
	cam.release()
	cv2.destroyAllWindows()
	message="Photo's captured Successfully"
	return render(request, 'index.html',{'Message':message})




	
def getmyattendence(request):
	userid=request.session['userid']
	print(userid)

	rollno="S_"+userid
	


	php=list(PHP_Attendence.objects.all().values('DateTime',rollno))	

	result_list = []
	#subject_list=[{'Sub':'PHP_Attendence'},{'Sub':'SN Attendance'},{'Sub':'AST Attendance'}]
	subject_list=["PHP_Attendence","SN Attendance","AST Attendance"]

	sn=list(SN_Attendance.objects.all().values('DateTime',rollno))
	
	ast=list(AST_Attendance.objects.all().values('DateTime',rollno))

	for d in php:
		d['RollNo'] = d.pop(''+rollno)
	for d in sn:
		d['RollNo'] = d.pop(''+rollno)

	for d in ast:
		d['RollNo'] = d.pop(''+rollno)


	def calculate_Present_lec(sub):
		count=0
		for lec in sub:
			if lec['RollNo']==1:
				count=count+1
		return count			

	php_present=calculate_Present_lec(php)
	sn_present=calculate_Present_lec(sn)
	ast_present=calculate_Present_lec(ast)
	
	

	print(php)
	return render_to_response("homepagestudent.html",
	{'Sub_P':"PHP",'t_p':len(php),'php_p':php_present,'php_a':len(php)-php_present,'php_percentage':((php_present/len(php))*100),
	'Sub_S':"SN",'t_s':len(sn),'sn_p':sn_present,'sn_a':len(sn)-sn_present,'sn_percentage':((sn_present/len(sn))*100),
	'Sub_A':"AST",'t_a':len(ast),'ast_p':ast_present,'ast_a':len(ast)-ast_present,'ast_percentage':((ast_present/len(ast))*100)})

	
def getsubjectattendence(request):
	userid=request.session['userid']
	print(userid)
	
	subject=list(FacultyDetails.objects.filter(Teacher_id=userid).values('Subject'))
	
	print("sbu", subject)

	sub=""+subject[0]['Subject']
	print(sub)

	if(sub=="PHP"):
		attendance=list(PHP_Attendence.objects.all().values('DateTime','S_15INFT10','S_15INFT18','S_15INFT33','S_15INFT47','S_15INFT49'))	
		print(attendance)
		return render(request,'homepagefaculty.html',{'Attendance':attendance})                                                                                 
	 	
	
	if(sub=="AST"):
		attendance=list(AST_Attendence.objects.all().values('DateTime','S_15INFT10','S_15INFT18','S_15INFT33','S_15INFT47','S_15INFT49'))	
		print(attendance)
	
	
	
	
	return render(request, "homepagefaculty.html")







def mark_attendence_manually(request):
	userid=request.session['userid']
	stud_list=list(StudentDetails.objects.all().values('Iso_RollNo','Name'))

	return render(request,'mark_attendence_manually.html',{'Stud_list':stud_list})


def save_attendenace_manually(request):
	print("In Save")
	att=[]
	iso_rollno=list(StudentDetails.objects.all().values('Iso_RollNo'))
	subject=request.POST['Subject_name']
	
	print("iso is",iso_rollno)
	for rollno in iso_rollno:
		att.append(request.POST[rollno['Iso_RollNo']])
		#att.append(request.POST[rollno['Iso_RollNo']])
	
	print("attendence is  ",att)
	flag=0
	now=strftime('%y-%m-%d %H:%M:%S', gmtime())
	if(subject=="PHP_Attendence"):
		sub_attendance=PHP_Attendence(DateTime=now,S_15INFT10=att[0],S_15INFT18=att[1],S_15INFT33=att[2],S_15INFT47=att[3],S_15INFT49=att[4])
		#sub_attendance=PHP_Attendence(DateTime=now,S_15INFT10=att[0])
		
		sub_attendance.save()
		flag=1

	if(subject=="SN_Attendance"):
		sub_attendance=SN_Attendance(DateTime=now,S_15INFT10=att[0],S_15INFT18=att[1],S_15INFT33=att[2],S_15INFT47=att[3],S_15INFT49=att[4])
		sub_attendance.save()
		flag=1

	if(subject=="AST_Attendence"):
		sub_attendance=PHP_Attendance(DateTime=now,S_15INFT10=att[0],S_15INFT18=att[1],S_15INFT33=att[2],S_15INFT47=att[3],S_15INFT49=att[4])
		sub_attendance.save()
		flag=1


	if flag==1:
		message="Attendance Marked Successfully....."
	else:
		message="Error ! Please try again."
			
	return render(request,'homepagefaculty.html',{'Message':message})















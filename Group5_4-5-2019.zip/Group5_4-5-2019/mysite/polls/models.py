from django.db import models
from datetime import datetime
# Create your models here.
class FacultyDetails(models.Model):
	Name=models.CharField(max_length=50)
	Teacher_id=models.CharField(max_length=25)
	Subject=models.CharField(max_length=25)
	Deapartment=models.CharField(max_length=20)
	Password=models.CharField(max_length=20)
	
	def __str__(self):
		return self.Name


class StudentDetails(models.Model):
	Name = models.CharField(max_length=50)
	Iso_RollNo = models.CharField(max_length=25)
	Email_id = models.CharField(max_length=25)
	Class = models.CharField(max_length=20)
	Password = models.CharField(max_length=20)

	def _str_(self):
		return self.Name

class Beit_Timetable(models.Model):
	Time=models.CharField(max_length=25)
	Monday=models.CharField(max_length=25)
	Tuesday=models.CharField(max_length=25)
	Wednseday=models.CharField(max_length=25)
	Thursday=models.CharField(max_length=25)
	Friday=models.CharField(max_length=25)

	def _str_(self):
		return self.Time

class PHP_Attendence(models.Model):
	DateTime=models.CharField(max_length=25)
	S_15INFT10 =models.CharField(max_length=1)
	S_15INFT18 =models.CharField(max_length=1)
	S_15INFT33 =models.CharField(max_length=1)
	S_15INFT47 =models.CharField(max_length=1)
	S_15INFT49 =models.CharField(max_length=1)
	def _str_(self):
		return self.DateTime
	

class SN_Attendance(models.Model):
	DateTime=models.CharField(max_length=25)
	S_15INFT10 =models.CharField(max_length=1)
	S_15INFT18 =models.CharField(max_length=1)
	S_15INFT33 =models.CharField(max_length=1)
	S_15INFT47 =models.CharField(max_length=1)
	S_15INFT49 =models.CharField(max_length=1)
	def _str_(self):
		return self.DateTime	

class AST_Attendance(models.Model):
	DateTime=models.CharField(max_length=25)
	S_15INFT10 =models.CharField(max_length=1)
	S_15INFT18 =models.CharField(max_length=1)
	S_15INFT33 =models.CharField(max_length=1)
	S_15INFT47 =models.CharField(max_length=1)
	S_15INFT49 =models.CharField(max_length=1)
	def _str_(self):
		return self.DateTime		
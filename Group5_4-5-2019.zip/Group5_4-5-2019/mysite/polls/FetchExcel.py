import mysql.connector
#from xlsxwriter.workbook import Workbook
from openpyxl import Workbook
mydb = mysql.connector.connect(
  host="localhost",
  user="root",
  passwd="",
  database="AttendenceSystem"
)

table="mysite_beit_ast_attendence"
Roll_no="Roll_no_1"
Date="Date"
Id="10"

query="SELECT "+Date+ "," +Roll_no+" FROM mysite_beit_ast_attendence"
mycursor = mydb.cursor()
mycursor.execute(query)
 
wb = Workbook()

results = mycursor.fetchall()
ws = wb.create_sheet(0)
ws.append('AST')
# ws.title = "student"
ws.append(mycursor.column_names)
for row in results:
    ws.append(row)

ws.append("BIS")	
query="SELECT "+Date+ "," +Roll_no+" FROM mysite_beit_bis_attendence "
mycursor = mydb.cursor()
mycursor.execute(query)
results = mycursor.fetchall()
ws.append(mycursor.column_names)
for row in results:
    ws.append(row)
	
ws.append("CC")	
query="SELECT "+Date+ "," +Roll_no+" FROM mysite_beit_cc_attendence "
mycursor = mydb.cursor()
mycursor.execute(query)
results = mycursor.fetchall()
ws.append(mycursor.column_names)
for row in results:
    ws.append(row)	

	
#workbook_name = "test_workbook"
wb.save(Id + ".xlsx")